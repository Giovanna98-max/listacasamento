function getParameterByName(name, url = window.location.href) {
  const params = new URL(url).searchParams;
  return params.get(name);
}

const guestId = getParameterByName("id");
const apiUrl = "https://script.google.com/macros/s/AKfycbwKcikBifiRRtNqKxE6fG5On1WBZC-saA1kLr0RME0PU6QtHJRwbDfWS8iO4-WZNjJu/exec";

if (guestId) {
  fetch(`${apiUrl}?id=${guestId}`)
    .then(res => res.json())
    .then(data => {
      const result = document.getElementById("result");
      if (data.found) {
        result.innerHTML = `
          <h2>Olá, ${data.nome}!</h2>
          <p>Status: <strong>${data.status}</strong></p>
          ${data.status === "pendente" ? "<button onclick='confirmar()'>Confirmar Presença</button>" : ""}
        `;
      } else {
        result.innerHTML = "<p>Convidado não encontrado.</p>";
      }
    });
}

function confirmar() {
  fetch(`${apiUrl}?id=${guestId}&confirmar=true`)
    .then(() => location.reload());
}
